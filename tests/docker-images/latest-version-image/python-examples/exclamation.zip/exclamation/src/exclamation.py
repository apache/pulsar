import sh

def process(input):
  return str(input) + '!'
